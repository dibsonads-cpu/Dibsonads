# Paid Ad Updates Tracker

Next.js App Router MVP for tracking verified paid media launches.

## Run locally

```bash
npm install
npm run dev
```

## Features

- Scannable feed with Country (All / UK / US / EU / Global) and Channel filters
- Dynamic OG cards at `/api/og`
- Detail pages `/updates/[slug]` with NewsArticle JSON-LD
- `/rss.xml` feed
- Email signup box (UI only)
- 8 sample entries based on real 2026 announcements

All visuals are generated safely via `@vercel/og`. Direct source links open in a new tab.
